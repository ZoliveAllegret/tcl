export const theme = {
  background: "#F4F1EB",
  card: "#FFFFFF",
  ink: "#161311",
  muted: "#746C64",
  line: "#E7E0D6",
  red: "#E10600",
  redSoft: "#FDECEA",
  live: "#0B7A43",
  liveSoft: "#E7F6EE",
  scheduled: "#8A5A12",
  scheduledSoft: "#F8F1E4",
  white: "#FFFFFF",
};

/** Couleurs publiques des lignes fortes. Les autres restent en encre. */
const LINE_COLORS: Record<string, string> = {
  A: "#E4007F",
  B: "#0070C0",
  C: "#F5A000",
  D: "#00A04A",
};

export function lineColor(line: string): string {
  if (LINE_COLORS[line]) {
    return LINE_COLORS[line];
  }
  if (line.startsWith("T")) {
    return "#6B2D5B";
  }
  if (line.startsWith("C")) {
    return "#1F4E79";
  }
  return "#3F3A36";
}

/** Les bus sans couleur de ligne publique s'affichent en bleu. */
export function vehicleMarkerColor(color: string): string {
  return color === "#3F3A36" ? "#1F6FD4" : color;
}

export type VehicleMode = "metro" | "tram" | "bus";

/** Métro A–D, tramway T1…, le reste est un bus (lignes C et navettes comprises). */
export function vehicleMode(line: string): VehicleMode {
  if (/^[ABCD]$/.test(line)) {
    return "metro";
  }
  if (/^T\d/.test(line)) {
    return "tram";
  }
  return "bus";
}

export const cardShadow = {
  shadowColor: "#161311",
  shadowOffset: { width: 0, height: 8 },
  shadowOpacity: 0.07,
  shadowRadius: 16,
  elevation: 3,
};
