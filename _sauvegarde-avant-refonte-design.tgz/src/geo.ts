import type { LatLng, MapRegion, Stop } from "@/src/types";

function toRadians(degrees: number): number {
  return (degrees * Math.PI) / 180;
}

export function distanceMeters(from: LatLng, to: LatLng): number {
  const earthRadius = 6_371_000;
  const latitudeDelta = toRadians(to.latitude - from.latitude);
  const longitudeDelta = toRadians(to.longitude - from.longitude);
  const fromLatitude = toRadians(from.latitude);
  const toLatitude = toRadians(to.latitude);
  const haversine =
    Math.sin(latitudeDelta / 2) ** 2 +
    Math.cos(fromLatitude) * Math.cos(toLatitude) * Math.sin(longitudeDelta / 2) ** 2;
  return 2 * earthRadius * Math.asin(Math.min(1, Math.sqrt(haversine)));
}

export function isInsideRegion(point: LatLng, region: MapRegion, padding = 0.15): boolean {
  const halfLatitude = (region.latitudeDelta * (1 + padding)) / 2;
  const halfLongitude = (region.longitudeDelta * (1 + padding)) / 2;
  return (
    Math.abs(point.latitude - region.latitude) <= halfLatitude &&
    Math.abs(point.longitude - region.longitude) <= halfLongitude
  );
}

export function nearestStops(stops: Stop[], origin: LatLng, limit: number, maxMeters: number): Stop[] {
  return stops
    .map((stop) => ({
      stop,
      meters: distanceMeters(origin, { latitude: stop.latitude, longitude: stop.longitude }),
    }))
    .filter((entry) => entry.meters <= maxMeters)
    .sort((left, right) => left.meters - right.meters)
    .slice(0, limit)
    .map((entry) => entry.stop);
}

export function formatDistance(meters: number): string {
  if (meters < 1000) {
    return `${Math.round(meters)} m`;
  }
  return `${(meters / 1000).toFixed(1)} km`;
}
