import { grandLyonConfig } from "@/src/config";
import {
  formatSiriDelay,
  lineFromSiriRef,
  parseLines,
  refValue,
  stopIdFromSiriRef,
} from "@/src/format";
import type { Passage, Stop, Vehicle } from "@/src/types";

type TableResponse<T> = {
  values?: T[];
};

type RawStop = {
  id: number;
  nom: string;
  commune: string | null;
  adresse: string | null;
  lat: number;
  lon: number;
  desserte: string | null;
  pmr: boolean | null;
};

type RawPassage = {
  id: number;
  ligne: string;
  direction: string;
  delaipassage: string;
  heurepassage: string;
  type: string;
  idtarretdestination: number | null;
};

const PAGE_SIZE = 1000;

function authorizationHeader(): string {
  return `Basic ${globalThis.btoa(`${grandLyonConfig.username}:${grandLyonConfig.password}`)}`;
}

async function fetchJson<T>(url: string, cache?: RequestCache): Promise<T> {
  const response = await fetch(url, {
    cache,
    headers: {
      Accept: "application/json",
      Authorization: authorizationHeader(),
    },
  });
  if (!response.ok) {
    throw new Error(`Le service Grand Lyon a répondu ${response.status}.`);
  }
  return (await response.json()) as T;
}

function mapStop(row: RawStop): Stop {
  return {
    id: row.id,
    name: row.nom,
    commune: row.commune ?? "",
    address: row.adresse,
    latitude: row.lat,
    longitude: row.lon,
    lines: parseLines(row.desserte),
    wheelchair: Boolean(row.pmr),
  };
}

function mapPassage(row: RawPassage): Passage {
  return {
    stopId: row.id,
    line: row.ligne,
    direction: row.direction,
    delayLabel: row.delaipassage,
    scheduledAt: row.heurepassage,
    kind: row.type === "E" ? "estimated" : "theoretical",
    destinationStopId: row.idtarretdestination,
  };
}

export async function fetchAllStops(onProgress?: (count: number) => void): Promise<Stop[]> {
  const stops: Stop[] = [];
  const seen = new Set<number>();
  let start = 1;

  while (start < 50_000) {
    const url = `${grandLyonConfig.stopsUrl}?compact=false&maxfeatures=${PAGE_SIZE}&start=${start}`;
    const page = await fetchJson<TableResponse<RawStop>>(url);
    const values = page.values ?? [];
    let added = 0;
    for (const row of values) {
      if (seen.has(row.id)) {
        continue;
      }
      seen.add(row.id);
      stops.push(mapStop(row));
      added += 1;
    }
    onProgress?.(stops.length);
    if (added === 0 || values.length < PAGE_SIZE) {
      break;
    }
    start += PAGE_SIZE;
  }

  stops.sort((left, right) => left.name.localeCompare(right.name, "fr"));
  return stops;
}

export async function fetchPassages(stopId: number): Promise<Passage[]> {
  const params = new URLSearchParams({
    compact: "false",
    maxfeatures: "100",
    field: "id",
    value: String(stopId),
  });
  const page = await fetchJson<TableResponse<RawPassage>>(`${grandLyonConfig.passagesUrl}?${params}`);
  return (page.values ?? [])
    .map(mapPassage)
    .sort((left, right) => left.scheduledAt.localeCompare(right.scheduledAt));
}

type SiriResponse = {
  Siri?: {
    ServiceDelivery?: {
      VehicleMonitoringDelivery?: Array<{
        VehicleActivity?: unknown;
      }>;
    };
  };
};

function asRecord(value: unknown): Record<string, unknown> | null {
  if (value && typeof value === "object") {
    return value as Record<string, unknown>;
  }
  return null;
}

function asActivities(value: unknown): Record<string, unknown>[] {
  if (Array.isArray(value)) {
    return value.map(asRecord).filter((item): item is Record<string, unknown> => item !== null);
  }
  const single = asRecord(value);
  return single ? [single] : [];
}

export async function fetchVehicles(): Promise<Vehicle[]> {
  const payload = await fetchJson<SiriResponse>(grandLyonConfig.vehiclesUrl, "no-store");
  const delivery = payload.Siri?.ServiceDelivery?.VehicleMonitoringDelivery?.[0];
  const activities = asActivities(delivery?.VehicleActivity);
  const vehicles: Vehicle[] = [];

  for (const activity of activities) {
    const journey = asRecord(activity.MonitoredVehicleJourney);
    const location = asRecord(journey?.VehicleLocation);
    const latitude = Number(location?.Latitude);
    const longitude = Number(location?.Longitude);
    if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
      continue;
    }
    const id = refValue(journey?.VehicleRef) ?? refValue(activity.VehicleMonitoringRef) ?? `${latitude},${longitude}`;
    const bearing = Number(journey?.Bearing);
    vehicles.push({
      id,
      line: lineFromSiriRef(refValue(journey?.LineRef)),
      latitude,
      longitude,
      bearing: Number.isFinite(bearing) ? bearing : null,
      delayLabel: formatSiriDelay(typeof journey?.Delay === "string" ? journey.Delay : null),
      destinationStopId: stopIdFromSiriRef(refValue(journey?.DestinationRef)),
      recordedAt: typeof activity.RecordedAtTime === "string" ? activity.RecordedAtTime : null,
    });
  }

  return vehicles;
}
