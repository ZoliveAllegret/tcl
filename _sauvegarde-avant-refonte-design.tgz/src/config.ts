/**
 * Compte de démonstration documenté par le portail data.grandlyon.com.
 * Remplace-le par un compte personnel si le quota de démo sature.
 */
export const grandLyonConfig = {
  username: "demo",
  password: "demo4dev",
  stopsUrl:
    "https://data.grandlyon.com/fr/datapusher/ws/rdata/tcl_sytral.tclarret/all.json",
  passagesUrl:
    "https://data.grandlyon.com/fr/datapusher/ws/rdata/tcl_sytral.tclpassagearret/all.json",
  vehiclesUrl: "https://data.grandlyon.com/siri-lite/2.0/vehicle-monitoring.json",
  gtfsUrl: "https://download.data.grandlyon.com/files/rdata/tcl_sytral.tcltheorique/GTFS_TCL.ZIP",
};

export const LYON_CENTER: { latitude: number; longitude: number } = {
  latitude: 45.7578,
  longitude: 4.832,
};
