import { grandLyonConfig } from "@/src/config";

export type ScheduledDeparture = {
  line: string;
  direction: string;
  time: string;
  at: number;
};

const HORIZON_MS = 20 * 60 * 60 * 1000;
const MAX_PER_DIRECTION = 8;
const WEEKDAYS = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];

type ActiveTrip = {
  line: string;
  direction: string;
  days: string[];
};

type DirectionGroup = {
  line: string;
  direction: string;
  times: number[];
};

let cachedDay = "";
let cachedIndex: Promise<Map<number, ScheduledDeparture[]>> | null = null;
let gtfsEntries: Promise<Map<string, Uint8Array>> | null = null;
let lineNames = new Map<string, string>();

export function getLineName(code: string): string | undefined {
  return lineNames.get(code);
}

function authorizationHeader(): string {
  return `Basic ${globalThis.btoa(`${grandLyonConfig.username}:${grandLyonConfig.password}`)}`;
}

function dayKey(date: Date): string {
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${date.getFullYear()}${month}${day}`;
}

function startOfLocalDay(date: Date): Date {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

function departureInstant(serviceDay: string, gtfsTime: string): number {
  const year = Number(serviceDay.slice(0, 4));
  const month = Number(serviceDay.slice(4, 6)) - 1;
  const day = Number(serviceDay.slice(6, 8));
  const [hours, minutes] = gtfsTime.split(":");
  const instant = new Date(year, month, day);
  instant.setMinutes(Number(hours) * 60 + Number(minutes));
  return instant.getTime();
}

function formatTime(at: number): string {
  return new Date(at).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
}

function readZipEntries(buffer: ArrayBuffer): Map<string, Uint8Array> {
  const bytes = new Uint8Array(buffer);
  const view = new DataView(buffer);
  const decoder = new TextDecoder();
  const entries = new Map<string, Uint8Array>();
  let offset = 0;

  while (offset + 30 <= bytes.length) {
    if (view.getUint32(offset, true) !== 0x04034b50) {
      break;
    }
    const flags = view.getUint16(offset + 6, true);
    const method = view.getUint16(offset + 8, true);
    const compressedSize = view.getUint32(offset + 18, true);
    const nameLength = view.getUint16(offset + 26, true);
    const extraLength = view.getUint16(offset + 28, true);
    const nameStart = offset + 30;
    const name = decoder.decode(bytes.subarray(nameStart, nameStart + nameLength));
    const dataStart = nameStart + nameLength + extraLength;
    if ((flags & 8) !== 0 || method !== 8) {
      throw new Error("Le fichier d'horaires TCL a un format inattendu.");
    }
    entries.set(name, bytes.subarray(dataStart, dataStart + compressedSize));
    offset = dataStart + compressedSize;
  }

  return entries;
}

function inflateStream(data: Uint8Array): ReadableStream<Uint8Array> {
  const copy = new Uint8Array(data.byteLength);
  copy.set(data);
  return new Blob([copy]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
}

async function inflateText(data: Uint8Array): Promise<string> {
  return new TextDecoder().decode(await new Response(inflateStream(data)).arrayBuffer());
}

async function forEachDataLine(data: Uint8Array, onLine: (line: string) => void): Promise<void> {
  const stream = inflateStream(data);
  const reader = stream.getReader();
  const decoder = new TextDecoder();
  let pending = "";

  const consume = (flush: boolean) => {
    pending += flush ? decoder.decode() : "";
    let newline = pending.indexOf("\n");
    while (newline >= 0) {
      let line = pending.slice(0, newline);
      pending = pending.slice(newline + 1);
      if (line.endsWith("\r")) {
        line = line.slice(0, -1);
      }
      if (line) {
        onLine(line);
      }
      newline = pending.indexOf("\n");
    }
  };

  while (true) {
    const chunk = await reader.read();
    if (chunk.done) {
      consume(true);
      if (pending) {
        onLine(pending.endsWith("\r") ? pending.slice(0, -1) : pending);
      }
      return;
    }
    pending += decoder.decode(chunk.value, { stream: true });
    consume(false);
  }
}

function rememberTime(group: DirectionGroup, at: number) {
  if (group.times.includes(at)) {
    return;
  }
  if (group.times.length < MAX_PER_DIRECTION) {
    group.times.push(at);
    return;
  }
  let latestIndex = 0;
  for (let index = 1; index < group.times.length; index += 1) {
    if (group.times[index] > group.times[latestIndex]) {
      latestIndex = index;
    }
  }
  if (at < group.times[latestIndex]) {
    group.times[latestIndex] = at;
  }
}

function parseLineNames(routesText: string): Map<string, string> {
  const names = new Map<string, string>();
  const routes = routesText.split("\n");
  const routeHeader = routes[0]?.replace(/^\uFEFF/, "").split(",") ?? [];
  const routeIndex = Object.fromEntries(routeHeader.map((name, index) => [name.trim(), index]));
  for (const rawLine of routes.slice(1)) {
    const line = rawLine.replace(/\r$/, "");
    if (!line) {
      continue;
    }
    const fields = line.split(",");
    const code = fields[routeIndex.route_short_name];
    const label = fields[routeIndex.route_long_name];
    if (code && label) {
      names.set(code, label.replaceAll(" - ", " – "));
    }
  }
  return names;
}

async function loadGtfsEntries(): Promise<Map<string, Uint8Array>> {
  if (typeof DecompressionStream === "undefined") {
    throw new Error("Cet appareil ne peut pas ouvrir le fichier d'horaires TCL.");
  }
  if (!gtfsEntries) {
    gtfsEntries = fetch(grandLyonConfig.gtfsUrl, {
      headers: {
        Authorization: authorizationHeader(),
      },
    })
      .then(async (response) => {
        if (!response.ok) {
          throw new Error(`Les horaires théoriques ont répondu ${response.status}.`);
        }
        return readZipEntries(await response.arrayBuffer());
      })
      .catch((error: unknown) => {
        gtfsEntries = null;
        throw error;
      });
  }
  return gtfsEntries;
}

export async function loadLineNames(): Promise<void> {
  if (lineNames.size > 0) {
    return;
  }
  const entries = await loadGtfsEntries();
  const routes = entries.get("routes.txt");
  if (!routes) {
    throw new Error("La liste des lignes est absente du fichier d'horaires.");
  }
  const names = parseLineNames(await inflateText(routes));
  if (lineNames.size === 0) {
    lineNames = names;
  }
}

async function buildIndex(onProgress?: (message: string) => void): Promise<Map<number, ScheduledDeparture[]>> {
  onProgress?.("Téléchargement des horaires…");
  const entries = await loadGtfsEntries();
  const required = ["calendar.txt", "calendar_dates.txt", "routes.txt", "trips.txt", "stop_times.txt"];
  for (const name of required) {
    if (!entries.has(name)) {
      throw new Error("Le fichier d'horaires TCL est incomplet.");
    }
  }

  const now = new Date();
  const from = now.getTime();
  const until = from + HORIZON_MS;
  const days = [startOfLocalDay(new Date(now.getTime() - 24 * 60 * 60 * 1000)), startOfLocalDay(now)];
  const dayKeys = new Set(days.map(dayKey));

  onProgress?.("Préparation des lignes…");
  const services = new Map<string, Set<string>>();
  const calendar = (await inflateText(entries.get("calendar.txt")!)).split("\n");
  const calendarHeader = calendar[0]?.replace(/^\uFEFF/, "").split(",") ?? [];
  const calendarIndex = Object.fromEntries(calendarHeader.map((name, index) => [name.trim(), index]));
  for (const rawLine of calendar.slice(1)) {
    const line = rawLine.replace(/\r$/, "");
    if (!line) {
      continue;
    }
    const fields = line.split(",");
    const serviceId = fields[calendarIndex.service_id];
    const start = fields[calendarIndex.start_date];
    const end = fields[calendarIndex.end_date];
    for (const day of days) {
      const key = dayKey(day);
      if (key < start || key > end || fields[calendarIndex[WEEKDAYS[day.getDay()]]] !== "1") {
        continue;
      }
      const active = services.get(serviceId) ?? new Set<string>();
      active.add(key);
      services.set(serviceId, active);
    }
  }

  const exceptions = (await inflateText(entries.get("calendar_dates.txt")!)).split("\n");
  for (const rawLine of exceptions.slice(1)) {
    const line = rawLine.replace(/\r$/, "");
    if (!line) {
      continue;
    }
    const [serviceId, date, exceptionType] = line.split(",");
    if (!dayKeys.has(date)) {
      continue;
    }
    const active = services.get(serviceId) ?? new Set<string>();
    if (exceptionType === "1") {
      active.add(date);
    } else if (exceptionType === "2") {
      active.delete(date);
    }
    services.set(serviceId, active);
  }

  const routeNames = new Map<string, string>();
  const routes = (await inflateText(entries.get("routes.txt")!)).split("\n");
  const routeHeader = routes[0]?.replace(/^\uFEFF/, "").split(",") ?? [];
  const routeIndex = Object.fromEntries(routeHeader.map((name, index) => [name.trim(), index]));
  const nextLineNames = parseLineNames(routes.join("\n"));
  for (const rawLine of routes.slice(1)) {
    const line = rawLine.replace(/\r$/, "");
    if (!line) {
      continue;
    }
    const fields = line.split(",");
    routeNames.set(fields[routeIndex.route_id], fields[routeIndex.route_short_name]);
  }
  lineNames = nextLineNames;

  const trips = new Map<string, ActiveTrip>();
  const tripLines = (await inflateText(entries.get("trips.txt")!)).split("\n");
  const tripHeader = tripLines[0]?.replace(/^\uFEFF/, "").split(",") ?? [];
  const tripIndex = Object.fromEntries(tripHeader.map((name, index) => [name.trim(), index]));
  for (const rawLine of tripLines.slice(1)) {
    const line = rawLine.replace(/\r$/, "");
    if (!line) {
      continue;
    }
    const fields = line.split(",");
    const activeDays = services.get(fields[tripIndex.service_id]);
    if (!activeDays || activeDays.size === 0) {
      continue;
    }
    trips.set(fields[tripIndex.trip_id], {
      line: routeNames.get(fields[tripIndex.route_id]) ?? "?",
      direction: fields[tripIndex.trip_headsign] || "Direction inconnue",
      days: [...activeDays],
    });
  }

  onProgress?.("Lecture des heures de passage…");
  const groups = new Map<number, Map<string, DirectionGroup>>();
  let seen = 0;
  await forEachDataLine(entries.get("stop_times.txt")!, (line) => {
    seen += 1;
    const clean = line.replace(/^\uFEFF/, "");
    if (seen === 1 && clean.startsWith("trip_id")) {
      return;
    }
    const fields = clean.split(",");
    const trip = trips.get(fields[0]);
    if (!trip || fields[6] === "1") {
      return;
    }
    const stopId = Number(fields[3]);
    if (!Number.isFinite(stopId)) {
      return;
    }
    for (const serviceDay of trip.days) {
      const at = departureInstant(serviceDay, fields[2]);
      if (at < from || at > until) {
        continue;
      }
      const stopGroups = groups.get(stopId) ?? new Map<string, DirectionGroup>();
      const key = `${trip.line}\0${trip.direction}`;
      const group = stopGroups.get(key) ?? { line: trip.line, direction: trip.direction, times: [] };
      rememberTime(group, at);
      stopGroups.set(key, group);
      groups.set(stopId, stopGroups);
    }
  });

  const index = new Map<number, ScheduledDeparture[]>();
  for (const [stopId, stopGroups] of groups) {
    const departures: ScheduledDeparture[] = [];
    for (const group of stopGroups.values()) {
      for (const at of group.times) {
        departures.push({
          line: group.line,
          direction: group.direction,
          at,
          time: formatTime(at),
        });
      }
    }
    departures.sort((left, right) => left.at - right.at);
    index.set(stopId, departures);
  }
  return index;
}

export function loadDepartures(stopId: number, onProgress?: (message: string) => void): Promise<ScheduledDeparture[]> {
  const today = dayKey(new Date());
  if (!cachedIndex || cachedDay !== today) {
    cachedDay = today;
    cachedIndex = buildIndex(onProgress).catch((error: unknown) => {
      cachedIndex = null;
      throw error;
    });
  }
  return cachedIndex.then((index) => index.get(stopId) ?? []);
}
