import { Stack } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import { StatusBar } from "expo-status-bar";
import { useEffect } from "react";

import { FavoritesProvider } from "@/src/favorites/FavoritesProvider";
import { StopsProvider } from "@/src/stops/StopsProvider";
import { theme } from "@/src/theme";

export { ErrorBoundary } from "expo-router";

SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  useEffect(() => {
    void SplashScreen.hideAsync();
  }, []);

  return (
    <StopsProvider>
      <FavoritesProvider>
        <StatusBar style="dark" />
        <Stack
          screenOptions={{
            headerStyle: { backgroundColor: theme.background },
            headerShadowVisible: false,
            headerTintColor: theme.ink,
            contentStyle: { backgroundColor: theme.background },
          }}
        >
          <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
          <Stack.Screen name="stop/[id]" options={{ title: "Arrêt" }} />
          <Stack.Screen name="line/[code]" options={{ title: "Ligne" }} />
        </Stack>
      </FavoritesProvider>
    </StopsProvider>
  );
}
