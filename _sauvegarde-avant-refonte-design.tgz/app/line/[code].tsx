import { router, Stack, useLocalSearchParams } from "expo-router";
import { useEffect, useMemo, useState } from "react";
import { FlatList, StyleSheet, Text, View } from "react-native";

import { LineChip } from "@/components/LineChip";
import { NavBar, useNavBarInset } from "@/components/NavBar";
import { StopRow } from "@/components/StopRow";
import { stopsOnLine } from "@/src/lines/groupLines";
import { getLineName, loadLineNames } from "@/src/schedule/theoretical";
import { useStops } from "@/src/stops/StopsProvider";
import { theme } from "@/src/theme";
import type { Stop } from "@/src/types";

export default function LineScreen() {
  const { code: rawCode } = useLocalSearchParams<{ code: string }>();
  const code = decodeURIComponent(rawCode ?? "");
  const { stops } = useStops();
  const [named, setNamed] = useState(Boolean(getLineName(code)));
  const navInset = useNavBarInset();
  const lineStops = useMemo(() => stopsOnLine(stops, code), [code, stops]);

  useEffect(() => {
    let cancelled = false;
    void loadLineNames()
      .then(() => {
        if (!cancelled) {
          setNamed(true);
        }
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, []);

  const label = named ? getLineName(code) : undefined;

  return (
    <View style={styles.screen}>
      <Stack.Screen options={{ title: code ? `Ligne ${code}` : "Ligne" }} />
      <FlatList
        data={lineStops}
        keyExtractor={(stop) => String(stop.id)}
        contentContainerStyle={[styles.list, { paddingBottom: navInset }]}
        ListHeaderComponent={
          <View style={styles.header}>
            <LineChip line={code} size="lg" />
            <Text style={styles.name}>{label ?? `Ligne ${code}`}</Text>
            <Text style={styles.meta}>
              {lineStops.length} {lineStops.length > 1 ? "arrêts" : "arrêt"}
            </Text>
          </View>
        }
        ListEmptyComponent={<Text style={styles.empty}>Aucun arrêt pour cette ligne.</Text>}
        renderItem={({ item }) => (
          <StopRow stop={item} lookupPlace={false} onPress={openStop} />
        )}
      />
      <NavBar />
    </View>
  );
}

function openStop(stop: Stop) {
  router.push({ pathname: "/stop/[id]", params: { id: String(stop.id) } });
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: theme.background,
  },
  list: {
    padding: 16,
    paddingBottom: 32,
  },
  header: {
    gap: 8,
    marginBottom: 16,
  },
  name: {
    color: theme.ink,
    fontSize: 22,
    fontWeight: "800",
    letterSpacing: -0.3,
    lineHeight: 28,
  },
  meta: {
    color: theme.muted,
    fontSize: 13,
  },
  empty: {
    color: theme.muted,
    fontSize: 16,
  },
});
