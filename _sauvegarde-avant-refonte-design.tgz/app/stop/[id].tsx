import { Stack, useFocusEffect, useLocalSearchParams } from "expo-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ActivityIndicator, Pressable, RefreshControl, ScrollView, StyleSheet, Text, View } from "react-native";

import { LineChip } from "@/components/LineChip";
import { NavBar, useNavBarInset } from "@/components/NavBar";
import { fetchPassages } from "@/src/api/grandLyon";
import { useFavorites } from "@/src/favorites/FavoritesProvider";
import { formatClock } from "@/src/format";
import { getLineName, loadDepartures, type ScheduledDeparture } from "@/src/schedule/theoretical";
import { usePlaceName } from "@/src/stops/placeName";
import { oppositePlatforms } from "@/src/stops/siblings";
import { useStops } from "@/src/stops/StopsProvider";
import { theme } from "@/src/theme";
import type { Passage } from "@/src/types";

const REFRESH_MS = 10_000;

function scheduleGroups(schedule: ScheduledDeparture[] | null): [string, ScheduledDeparture[]][] {
  const groups = new Map<string, ScheduledDeparture[]>();
  for (const departure of schedule ?? []) {
    const key = `${departure.line}\0${departure.direction}`;
    const current = groups.get(key) ?? [];
    current.push(departure);
    groups.set(key, current);
  }
  return [...groups.entries()];
}

export default function StopScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const stopId = Number(id);
  const { getStop, stops } = useStops();
  const { isFavorite, toggle } = useFavorites();
  const stop = Number.isFinite(stopId) ? getStop(stopId) : undefined;
  const placeName = usePlaceName(stop);
  const platformIds = useMemo(() => {
    if (!Number.isFinite(stopId)) {
      return [];
    }
    if (!stop) {
      return [stopId];
    }
    return [stop.id, ...oppositePlatforms(stop, stops).map((platform) => platform.id)];
  }, [stop, stopId, stops]);
  const [passages, setPassages] = useState<Passage[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [schedule, setSchedule] = useState<ScheduledDeparture[] | null>(null);
  const [scheduleStatus, setScheduleStatus] = useState("Chargement des horaires…");
  const [scheduleError, setScheduleError] = useState<string | null>(null);
  const requestRef = useRef(0);
  const navInset = useNavBarInset();

  useEffect(() => {
    setLoading(true);
    setPassages([]);
    setError(null);
    setSchedule(null);
    setScheduleError(null);
    setScheduleStatus("Chargement des horaires…");
  }, [stopId]);

  useEffect(() => {
    if (!Number.isFinite(stopId)) {
      return;
    }
    let cancelled = false;
    Promise.all(platformIds.map((platformId) => loadDepartures(platformId, (message) => {
      if (!cancelled) {
        setScheduleStatus(message);
      }
    })))
      .then((groups) => {
        if (!cancelled) {
          setSchedule(groups.flat().sort((left, right) => left.at - right.at));
        }
      })
      .catch((cause: unknown) => {
        if (!cancelled) {
          setScheduleError(cause instanceof Error ? cause.message : "Horaires indisponibles.");
        }
      });
    return () => {
      cancelled = true;
    };
  }, [platformIds, stopId]);

  const load = useCallback(
    async (manual: boolean) => {
      const request = ++requestRef.current;
      if (!Number.isFinite(stopId)) {
        setError("Arrêt inconnu.");
        setLoading(false);
        return;
      }
      if (manual) {
        setRefreshing(true);
      }
      try {
        const groups = await Promise.all(platformIds.map((platformId) => fetchPassages(platformId)));
        const next = groups.flat().sort((left, right) => left.scheduledAt.localeCompare(right.scheduledAt));
        if (request !== requestRef.current) {
          return;
        }
        setPassages(next);
        setError(null);
      } catch (cause) {
        if (request !== requestRef.current) {
          return;
        }
        setError(cause instanceof Error ? cause.message : "Passages indisponibles.");
      } finally {
        if (request === requestRef.current) {
          setLoading(false);
          setRefreshing(false);
        }
      }
    },
    [platformIds, stopId],
  );

  useFocusEffect(
    useCallback(() => {
      void load(false);
      const timer = setInterval(() => {
        void load(false);
      }, REFRESH_MS);
      return () => clearInterval(timer);
    }, [load]),
  );

  const groups = new Map<string, Passage[]>();
  for (const passage of passages) {
    const current = groups.get(passage.line) ?? [];
    current.push(passage);
    groups.set(passage.line, current);
  }

  return (
    <View style={styles.screen}>
      <Stack.Screen
        options={{
          title: stop?.name ?? "Arrêt",
          headerRight: () =>
            Number.isFinite(stopId) ? (
              <Pressable
                onPress={() => void toggle(stopId)}
                style={styles.favorite}
                accessibilityRole="button"
                accessibilityLabel={isFavorite(stopId) ? "Retirer des favoris" : "Ajouter aux favoris"}
              >
                <Text style={styles.favoriteLabel}>{isFavorite(stopId) ? "Retirer" : "Favori"}</Text>
              </Pressable>
            ) : null,
        }}
      />
      <ScrollView
        contentContainerStyle={[styles.content, { paddingBottom: navInset }]}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => void load(true)} tintColor={theme.red} />}
      >
        <Text style={styles.commune}>{placeName || stop?.commune || "Arrêt TCL"}</Text>
        {stop?.address ? <Text style={styles.address}>{stop.address}</Text> : null}
        {stop ? (
          <View style={styles.lines}>
            {stop.lines.map((line) => (
              <View key={line} style={styles.lineIdentity}>
                <LineChip line={line} />
                {getLineName(line) ? <Text style={styles.lineName}>{getLineName(line)}</Text> : null}
              </View>
            ))}
            {stop.wheelchair ? <Text style={styles.pmr}>Accessible PMR</Text> : null}
          </View>
        ) : null}

        {loading ? <ActivityIndicator color={theme.red} style={styles.loader} /> : null}
        {error ? <Text style={styles.error}>{error}</Text> : null}
        {!loading && !error && passages.length === 0 ? (
          <Text style={styles.empty}>Pas de passage en temps réel pour le moment.</Text>
        ) : null}

        {[...groups.entries()].map(([line, items]) => (
          <View key={line} style={styles.group}>
            <View style={styles.scheduleHead}>
              <LineChip line={line} />
              {getLineName(line) ? <Text style={styles.lineName}>{getLineName(line)}</Text> : null}
            </View>
            {items.map((passage) => (
              <View key={`${passage.line}-${passage.direction}-${passage.scheduledAt}`} style={styles.passage}>
                <View style={styles.passageCopy}>
                  <Text style={styles.direction}>{passage.direction}</Text>
                  <Text style={[styles.kind, passage.kind === "estimated" ? styles.live : styles.scheduled]}>
                    {passage.kind === "estimated" ? "Temps réel" : "Horaire théorique"}
                    {passage.scheduledAt ? ` · ${formatClock(passage.scheduledAt)}` : ""}
                  </Text>
                </View>
                <Text style={styles.delay}>{passage.delayLabel}</Text>
              </View>
            ))}
          </View>
        ))}

        <Text style={styles.sectionTitle}>Horaires</Text>
        <Text style={styles.sectionHint}>Les deux sens, sur les prochaines 20 heures</Text>
        {schedule === null && !scheduleError ? <Text style={styles.empty}>{scheduleStatus}</Text> : null}
        {scheduleError ? <Text style={styles.error}>{scheduleError}</Text> : null}
        {schedule && schedule.length === 0 ? (
          <Text style={styles.empty}>Aucun horaire prévu sur cette période.</Text>
        ) : null}
        {scheduleGroups(schedule).map(([key, items]) => (
          <View key={key} style={styles.group}>
            <View style={styles.scheduleHead}>
              <LineChip line={items[0].line} />
              <View style={styles.lineCopy}>
                {getLineName(items[0].line) ? <Text style={styles.lineName}>{getLineName(items[0].line)}</Text> : null}
                <Text style={styles.direction}>vers {items[0].direction}</Text>
              </View>
            </View>
            <View style={styles.times}>
              {items.map((item) => (
                <Text key={`${key}-${item.at}`} style={styles.time}>
                  {item.time}
                </Text>
              ))}
            </View>
          </View>
        ))}
      </ScrollView>
      <NavBar />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: theme.background,
  },
  content: {
    padding: 16,
    paddingBottom: 40,
    gap: 8,
  },
  commune: {
    color: theme.ink,
    fontSize: 15,
    fontWeight: "600",
  },
  address: {
    color: theme.muted,
  },
  lines: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 6,
    alignItems: "center",
    marginTop: 8,
    marginBottom: 8,
  },
  pmr: {
    color: theme.muted,
    fontSize: 13,
  },
  loader: {
    marginVertical: 16,
  },
  error: {
    color: theme.red,
    marginVertical: 8,
  },
  empty: {
    color: theme.muted,
    fontSize: 16,
    marginTop: 12,
    lineHeight: 22,
  },
  sectionTitle: {
    color: theme.ink,
    fontSize: 22,
    fontWeight: "800",
    letterSpacing: -0.4,
    marginTop: 22,
  },
  sectionHint: {
    color: theme.muted,
    fontSize: 13,
    marginBottom: 4,
  },
  lineIdentity: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    flexBasis: "100%",
  },
  lineCopy: {
    flex: 1,
    gap: 2,
  },
  lineName: {
    flex: 1,
    color: theme.ink,
    fontSize: 14,
    fontWeight: "700",
    lineHeight: 18,
  },
  scheduleHead: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  times: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
  },
  time: {
    color: theme.ink,
    backgroundColor: theme.background,
    borderRadius: 8,
    overflow: "hidden",
    paddingHorizontal: 10,
    paddingVertical: 8,
    fontSize: 18,
    fontWeight: "800",
    fontVariant: ["tabular-nums"],
  },
  group: {
    backgroundColor: theme.card,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: theme.line,
    padding: 12,
    gap: 10,
    marginTop: 8,
  },
  passage: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  passageCopy: {
    flex: 1,
    gap: 2,
  },
  direction: {
    color: theme.ink,
    fontSize: 16,
    fontWeight: "600",
  },
  kind: {
    fontSize: 13,
  },
  live: {
    color: theme.live,
  },
  scheduled: {
    color: theme.scheduled,
  },
  delay: {
    color: theme.ink,
    fontSize: 20,
    fontWeight: "800",
    fontVariant: ["tabular-nums"],
  },
  favorite: {
    marginRight: 12,
  },
  favoriteLabel: {
    color: theme.red,
    fontWeight: "700",
  },
});
