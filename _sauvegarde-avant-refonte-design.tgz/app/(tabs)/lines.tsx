import { router } from "expo-router";
import { useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { Pressable, SectionList, StyleSheet, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { LineChip } from "@/components/LineChip";
import { useNavBarInset } from "@/components/NavBar";
import { ScreenHeader } from "@/components/ScreenHeader";
import { collectLines, sectionLines, type LineSummary } from "@/src/lines/groupLines";
import { getLineName, loadLineNames } from "@/src/schedule/theoretical";
import { searchTarget, searchToken, subscribeSearch } from "@/src/search/session";
import { useStops } from "@/src/stops/StopsProvider";
import { theme } from "@/src/theme";

export default function LinesScreen() {
  const { stops, loading } = useStops();
  const [query, setQuery] = useState("");
  const inputRef = useRef<TextInput>(null);
  const token = useSyncExternalStore(subscribeSearch, searchToken, searchToken);
  const navInset = useNavBarInset();
  const [namesReady, setNamesReady] = useState(false);
  const lines = useMemo(() => collectLines(stops), [stops]);
  const sections = useMemo(() => sectionLines(lines, query, getLineName), [lines, query, namesReady]);

  useEffect(() => {
    if (token === 0 || searchTarget() !== "lines") {
      return;
    }
    setQuery("");
    inputRef.current?.focus();
  }, [token]);

  useEffect(() => {
    let cancelled = false;
    void loadLineNames()
      .then(() => {
        if (!cancelled) {
          setNamesReady(true);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setNamesReady(true);
        }
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <SafeAreaView style={styles.screen} edges={["top"]}>
      <ScreenHeader title="Lignes">
        <TextInput
          ref={inputRef}
          value={query}
          onChangeText={setQuery}
          placeholder="Code de ligne, par exemple 121 ou T1"
          placeholderTextColor={theme.muted}
          autoCorrect={false}
          autoCapitalize="characters"
          style={styles.input}
          clearButtonMode="while-editing"
        />
        <Text style={styles.status}>
          {loading
            ? "Chargement des lignes…"
            : namesReady
              ? `${lines.length} lignes`
              : `${lines.length} lignes · noms en cours de chargement`}
        </Text>
      </ScreenHeader>
      <SectionList
        sections={sections}
        keyExtractor={(line) => line.code}
        contentContainerStyle={[styles.list, { paddingBottom: navInset }]}
        stickySectionHeadersEnabled
        ListEmptyComponent={
          <Text style={styles.empty}>{loading ? "Chargement des lignes…" : "Aucune ligne"}</Text>
        }
        renderSectionHeader={({ section }) => (
          <Text style={styles.section}>{section.title}</Text>
        )}
        renderItem={({ item }) => (
          <LineRow line={item} named={namesReady} onPress={() => openLine(item.code)} />
        )}
      />
    </SafeAreaView>
  );
}

function openLine(code: string) {
  router.push({ pathname: "/line/[code]", params: { code } });
}

function LineRow({ line, named, onPress }: { line: LineSummary; named: boolean; onPress: () => void }) {
  const label = named ? getLineName(line.code) : undefined;
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [styles.row, pressed && styles.pressed]}
      accessibilityRole="button"
      accessibilityLabel={label ? `Ligne ${line.code}, ${label}` : `Ligne ${line.code}`}
    >
      <LineChip line={line.code} size="lg" />
      <View style={styles.copy}>
        <Text style={styles.name} numberOfLines={2}>
          {label ?? line.code}
        </Text>
        <Text style={styles.meta}>
          {line.stopCount} {line.stopCount > 1 ? "arrêts" : "arrêt"}
        </Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: theme.background,
  },
  input: {
    backgroundColor: theme.background,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 16,
    color: theme.ink,
  },
  status: {
    color: theme.muted,
    fontSize: 13,
  },
  list: {
    paddingHorizontal: 16,
    paddingBottom: 28,
  },
  section: {
    backgroundColor: theme.background,
    color: theme.muted,
    fontSize: 13,
    fontWeight: "800",
    letterSpacing: 0.6,
    textTransform: "uppercase",
    paddingTop: 16,
    paddingBottom: 8,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    backgroundColor: theme.card,
    borderRadius: 14,
    paddingHorizontal: 12,
    paddingVertical: 12,
    marginBottom: 8,
  },
  pressed: {
    backgroundColor: "#F7F4EF",
  },
  copy: {
    flex: 1,
    gap: 2,
  },
  name: {
    color: theme.ink,
    fontSize: 15,
    fontWeight: "700",
    lineHeight: 20,
  },
  meta: {
    color: theme.muted,
    fontSize: 12,
  },
  empty: {
    color: theme.muted,
    padding: 20,
  },
});
