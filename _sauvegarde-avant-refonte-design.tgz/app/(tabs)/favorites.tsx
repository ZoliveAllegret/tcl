import { router } from "expo-router";
import { useMemo } from "react";
import { FlatList, StyleSheet, Text, View } from "react-native";

import { useNavBarInset } from "@/components/NavBar";
import { StopRow } from "@/components/StopRow";
import { useFavorites } from "@/src/favorites/FavoritesProvider";
import { useStops } from "@/src/stops/StopsProvider";
import { theme } from "@/src/theme";
import type { Stop } from "@/src/types";

export default function FavoritesScreen() {
  const { ids, ready } = useFavorites();
  const { stops, loading } = useStops();
  const navInset = useNavBarInset();

  const favorites = useMemo(
    () => ids.map((id) => stops.find((stop) => stop.id === id)).filter((stop): stop is Stop => Boolean(stop)),
    [ids, stops],
  );
  const waiting = !ready || (ids.length > 0 && stops.length === 0 && loading);

  return (
    <View style={styles.screen}>
      <FlatList
        data={favorites}
        keyExtractor={(stop) => String(stop.id)}
        contentContainerStyle={[styles.list, { paddingBottom: navInset }]}
        ListEmptyComponent={
          <Text style={styles.empty}>
            {waiting ? "Chargement des favoris…" : "Aucun favori. Ouvre un arrêt et ajoute-le."}
          </Text>
        }
        renderItem={({ item }) => (
          <StopRow
            stop={item}
            onPress={(stop) => router.push({ pathname: "/stop/[id]", params: { id: String(stop.id) } })}
          />
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: theme.background,
  },
  list: {
    padding: 16,
    flexGrow: 1,
  },
  empty: {
    color: theme.muted,
    fontSize: 16,
    lineHeight: 22,
  },
});
