import { router, Stack } from "expo-router";
import { useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { ActivityIndicator, Pressable, SectionList, StyleSheet, Text, TextInput, View } from "react-native";

import { useNavBarInset } from "@/components/NavBar";
import { StopRow } from "@/components/StopRow";
import { useFavorites } from "@/src/favorites/FavoritesProvider";
import { distanceMeters, formatDistance, nearestStops } from "@/src/geo";
import { normalizeText } from "@/src/format";
import { useUserLocation } from "@/src/hooks/useUserLocation";
import { searchTarget, searchToken, subscribeSearch } from "@/src/search/session";
import { useStops } from "@/src/stops/StopsProvider";
import { theme } from "@/src/theme";
import type { Stop } from "@/src/types";

function openStop(stop: Stop) {
  router.push({ pathname: "/stop/[id]", params: { id: String(stop.id) } });
}

export default function SearchScreen() {
  const { stops, loading, error, loadedCount, refresh } = useStops();
  const { ids } = useFavorites();
  const userLocation = useUserLocation();
  const [query, setQuery] = useState("");
  const inputRef = useRef<TextInput>(null);
  const token = useSyncExternalStore(subscribeSearch, searchToken, searchToken);
  const navInset = useNavBarInset();

  useEffect(() => {
    if (token === 0 || searchTarget() !== "stops") {
      return;
    }
    setQuery("");
    inputRef.current?.focus();
  }, [token]);

  const normalized = normalizeText(query);
  const results = useMemo(() => {
    if (normalized.length < 2) {
      return [];
    }
    const prefix: Stop[] = [];
    const contains: Stop[] = [];
    for (const stop of stops) {
      const name = normalizeText(stop.name);
      const commune = normalizeText(stop.commune);
      if (name.startsWith(normalized)) {
        prefix.push(stop);
      } else if (name.includes(normalized) || commune.includes(normalized)) {
        contains.push(stop);
      }
    }
    return [...prefix, ...contains].slice(0, 40);
  }, [normalized, stops]);

  const favorites = useMemo(
    () => ids.map((id) => stops.find((stop) => stop.id === id)).filter((stop): stop is Stop => Boolean(stop)),
    [ids, stops],
  );

  const nearby = useMemo(() => {
    if (!userLocation || normalized.length >= 2) {
      return [];
    }
    return nearestStops(stops, userLocation, 8, 1200);
  }, [normalized.length, stops, userLocation]);

  const sections = useMemo(() => {
    const rows = (prefix: string, items: Stop[]) =>
      items.map((stop) => ({ ...stop, rowKey: `${prefix}-${stop.id}` }));
    if (normalized.length >= 2) {
      return [{ title: results.length === 0 ? "Aucun arrêt" : "Résultats", data: rows("result", results) }];
    }
    const next: { title: string; data: Array<Stop & { rowKey: string }> }[] = [];
    if (favorites.length > 0) {
      next.push({ title: "Favoris", data: rows("favorite", favorites) });
    }
    if (nearby.length > 0) {
      next.push({ title: "Autour de vous", data: rows("nearby", nearby) });
    }
    if (next.length === 0) {
      next.push({ title: "Saisis au moins deux lettres", data: [] });
    }
    return next;
  }, [favorites, nearby, normalized.length, results]);

  return (
    <View style={styles.screen}>
      <Stack.Screen options={{ title: "Arrêts" }} />
      <TextInput
        ref={inputRef}
        value={query}
        onChangeText={setQuery}
        placeholder="Nom d'arrêt ou commune"
        placeholderTextColor={theme.muted}
        autoCorrect={false}
        autoCapitalize="words"
        style={styles.input}
        clearButtonMode="while-editing"
      />
      {loading && stops.length === 0 ? (
        <View style={styles.center}>
          <ActivityIndicator color={theme.red} />
          <Text style={styles.hint}>{loadedCount > 0 ? `${loadedCount} arrêts` : "Chargement des arrêts TCL…"}</Text>
        </View>
      ) : null}
      {error && stops.length === 0 ? (
        <View style={styles.center}>
          <Text style={styles.error}>{error}</Text>
          <Pressable onPress={() => void refresh()} style={styles.retry}>
            <Text style={styles.retryLabel}>Réessayer</Text>
          </Pressable>
        </View>
      ) : null}
      {!loading || stops.length > 0 ? (
        <SectionList
          sections={sections}
          keyExtractor={(stop) => stop.rowKey}
          stickySectionHeadersEnabled={false}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={[styles.list, { paddingBottom: navInset }]}
          renderSectionHeader={({ section }) => <Text style={styles.section}>{section.title}</Text>}
          renderItem={({ item }) => (
            <StopRow
              stop={item}
              detail={
                userLocation
                  ? formatDistance(
                      distanceMeters(userLocation, {
                        latitude: item.latitude,
                        longitude: item.longitude,
                      }),
                    )
                  : undefined
              }
              onPress={openStop}
            />
          )}
        />
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: theme.background,
  },
  input: {
    margin: 16,
    marginBottom: 8,
    backgroundColor: theme.card,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: theme.line,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 16,
    color: theme.ink,
  },
  list: {
    paddingHorizontal: 16,
    paddingBottom: 32,
  },
  section: {
    color: theme.muted,
    fontSize: 13,
    fontWeight: "700",
    letterSpacing: 0.4,
    textTransform: "uppercase",
    marginTop: 8,
    marginBottom: 10,
  },
  center: {
    alignItems: "center",
    gap: 12,
    padding: 24,
  },
  hint: {
    color: theme.muted,
  },
  error: {
    color: theme.ink,
    textAlign: "center",
  },
  retry: {
    backgroundColor: theme.red,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  retryLabel: {
    color: theme.white,
    fontWeight: "700",
  },
});
