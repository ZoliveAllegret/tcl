import { router } from "expo-router";
import { useCallback, useMemo, useRef, useState } from "react";
import { Pressable, StyleSheet, Text, TextInput, View } from "react-native";

import { useNavBarInset } from "@/components/NavBar";
import { NetworkMap, type NetworkMapHandle } from "@/components/NetworkMap";
import { LYON_CENTER } from "@/src/config";
import { formatClock } from "@/src/format";
import { isInsideRegion, nearestStops } from "@/src/geo";
import { useUserLocation } from "@/src/hooks/useUserLocation";
import { useVehicles } from "@/src/hooks/useVehicles";
import { useStops } from "@/src/stops/StopsProvider";
import { lineColor, theme, vehicleMarkerColor, vehicleMode } from "@/src/theme";
import type { MapRegion } from "@/src/types";

export default function MapScreen() {
  const mapRef = useRef<NetworkMapHandle>(null);
  const navInset = useNavBarInset();
  const { stops, getStop } = useStops();
  const userLocation = useUserLocation();
  const { vehicles, loading, error, updatedAt } = useVehicles(true);
  const [region, setRegion] = useState<MapRegion | null>(null);
  const [lineQuery, setLineQuery] = useState("");
  const [selectedVehicleId, setSelectedVehicleId] = useState<string | null>(null);

  const onRegionChange = useCallback((next: MapRegion) => {
    setRegion((current) => {
      if (
        current &&
        Math.abs(current.latitude - next.latitude) < 0.00001 &&
        Math.abs(current.longitude - next.longitude) < 0.00001 &&
        Math.abs(current.latitudeDelta - next.latitudeDelta) < 0.00001
      ) {
        return current;
      }
      return next;
    });
  }, []);

  const visibleStops = useMemo(() => {
    if (!region) {
      return [];
    }
    const inside = stops.filter((stop) => isInsideRegion(stop, region));
    if (inside.length <= 140) {
      return inside;
    }
    return nearestStops(inside, region, 140, Number.POSITIVE_INFINITY);
  }, [region, stops]);

  const visibleVehicles = useMemo(() => {
    const query = lineQuery.trim().toLowerCase();
    return vehicles.filter((vehicle) => {
      if (query && !vehicle.line.toLowerCase().includes(query)) {
        return false;
      }
      return region ? isInsideRegion(vehicle, region, 0.02) : true;
    });
  }, [lineQuery, region, vehicles]);

  const selected = vehicles.find((vehicle) => vehicle.id === selectedVehicleId) ?? null;
  const destination = selected?.destinationStopId ? getStop(selected.destinationStopId) : undefined;

  return (
    <View style={[styles.screen, { paddingBottom: navInset }]}>
      <View style={styles.filterWrap}>
        <TextInput
          value={lineQuery}
          onChangeText={setLineQuery}
          placeholder="Filtrer une ligne"
          placeholderTextColor={theme.muted}
          autoCorrect={false}
          autoCapitalize="characters"
          style={styles.filter}
        />
        <Pressable
          style={styles.locate}
          onPress={() => mapRef.current?.focusOn(userLocation ?? LYON_CENTER)}
        >
          <Text style={styles.locateLabel}>Moi</Text>
        </Pressable>
      </View>
      <NetworkMap
        ref={mapRef}
        userLocation={userLocation}
        onRegionChange={onRegionChange}
        onSelectStop={(id) => router.push({ pathname: "/stop/[id]", params: { id: String(id) } })}
        onSelectVehicle={setSelectedVehicleId}
        stops={visibleStops.map((stop) => ({
          id: stop.id,
          name: stop.name,
          latitude: stop.latitude,
          longitude: stop.longitude,
          lines: stop.lines,
        }))}
        vehicles={visibleVehicles.map((vehicle) => ({
          id: vehicle.id,
          line: vehicle.line,
          latitude: vehicle.latitude,
          longitude: vehicle.longitude,
          bearing: vehicle.bearing,
          delayLabel: vehicle.delayLabel,
          destination: vehicle.destinationStopId ? (getStop(vehicle.destinationStopId)?.name ?? null) : null,
          color: vehicleMarkerColor(lineColor(vehicle.line)),
          mode: vehicleMode(vehicle.line),
        }))}
      />
      <View style={styles.sheet}>
        {selected ? (
          <View>
            <Text style={styles.sheetTitle}>
              Ligne {selected.line}
              {selected.delayLabel ? ` · ${selected.delayLabel}` : ""}
            </Text>
            <Text style={styles.sheetMeta}>
              {destination ? `Vers ${destination.name}` : "Destination non publiée"}
              {selected.recordedAt ? ` · ${formatClock(selected.recordedAt)}` : ""}
            </Text>
          </View>
        ) : (
          <View>
            <Text style={styles.sheetTitle}>
              {loading && vehicles.length === 0
                ? "Chargement des véhicules…"
                : visibleVehicles.length === 1
                  ? "1 véhicule à l'écran"
                  : `${visibleVehicles.length} véhicules à l'écran`}
            </Text>
            <Text style={styles.sheetMeta}>
              {error ?? (updatedAt ? `Mis à jour à ${formatClock(updatedAt.toISOString())}` : "Positions SIRI-Lite")}
            </Text>
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: theme.background,
  },
  filterWrap: {
    position: "absolute",
    zIndex: 2,
    top: 12,
    left: 12,
    right: 12,
    flexDirection: "row",
    gap: 8,
  },
  filter: {
    flex: 1,
    backgroundColor: theme.card,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: theme.line,
    paddingHorizontal: 12,
    paddingVertical: 10,
    color: theme.ink,
    fontSize: 16,
  },
  locate: {
    backgroundColor: theme.ink,
    borderRadius: 12,
    paddingHorizontal: 14,
    justifyContent: "center",
  },
  locateLabel: {
    color: theme.white,
    fontWeight: "700",
  },
  sheet: {
    backgroundColor: theme.card,
    borderTopWidth: 1,
    borderTopColor: theme.line,
    paddingHorizontal: 16,
    paddingVertical: 14,
  },
  sheetTitle: {
    color: theme.ink,
    fontSize: 16,
    fontWeight: "700",
  },
  sheetMeta: {
    color: theme.muted,
    marginTop: 4,
  },
});
