import { Tabs } from "expo-router";

import { NavBar } from "@/components/NavBar";
import { theme } from "@/src/theme";

export default function TabLayout() {
  return (
    <Tabs
      tabBar={() => <NavBar />}
      screenOptions={{
        headerStyle: { backgroundColor: theme.background },
        headerShadowVisible: false,
        headerTintColor: theme.ink,
        sceneStyle: { backgroundColor: theme.background },
      }}
    >
      <Tabs.Screen name="index" options={{ title: "Arrêts", headerShown: false }} />
      <Tabs.Screen name="lines" options={{ title: "Lignes", headerShown: false }} />
      <Tabs.Screen name="map" options={{ title: "Carte" }} />
      <Tabs.Screen name="favorites" options={{ title: "Favoris" }} />
    </Tabs>
  );
}
