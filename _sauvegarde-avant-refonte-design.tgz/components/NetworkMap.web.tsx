import { createElement, forwardRef, useEffect, useImperativeHandle, useRef } from "react";
import { StyleSheet, View } from "react-native";

import type { NetworkMapHandle, NetworkMapProps } from "@/components/mapTypes";
import type { LatLng, MapRegion } from "@/src/types";

const MAP_DOCUMENT = `<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
  <style>
    html, body, #map { margin: 0; height: 100%; background: #e7e0d6; }
    .veh {
      width: 44px;
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    .veh svg {
      display: block;
      transform-origin: center center;
      filter: drop-shadow(0 1px 2px rgba(22, 19, 17, 0.35));
    }
    .veh span {
      margin-top: 1px;
      background: #fff;
      color: #161311;
      font: 800 11px/1.1 sans-serif;
      padding: 2px 5px;
      border-radius: 999px;
      box-shadow: 0 1px 3px rgba(22, 19, 17, 0.28);
    }
  </style>
</head>
<body>
  <div id="map"></div>
  <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
  <script>
    const map = L.map('map', { zoomControl: true }).setView([45.7578, 4.832], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap'
    }).addTo(map);
    const stopsLayer = L.layerGroup().addTo(map);
    const vehiclesLayer = L.layerGroup().addTo(map);
    const userLayer = L.layerGroup().addTo(map);
    const vehicleMotions = new Map();
    const SLIDE_MS = 10000;

    const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, (ch) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[ch]));

    function travelHeading(fromLat, fromLng, toLat, toLng, bearing) {
      const dLat = toLat - fromLat;
      const dLng = toLng - fromLng;
      if (Math.abs(dLat) > 0.00002 || Math.abs(dLng) > 0.00002) {
        return (Math.atan2(dLng, dLat) * 180 / Math.PI + 360) % 360;
      }
      return typeof bearing === "number" && !Number.isNaN(bearing) ? bearing : null;
    }

    function vehicleBody(mode, color) {
      if (mode === "tram") {
        return '<rect x="8" y="0.5" width="8" height="16" rx="1.4" fill="' + color + '"/>' +
          '<rect x="8" y="19.2" width="8" height="16.3" rx="1.4" fill="' + color + '"/>' +
          '<rect x="9.6" y="2.2" width="4.8" height="2.2" rx="0.5" fill="#fff"/>' +
          '<rect x="11.2" y="6" width="1.6" height="8" rx="0.4" fill="#fff"/>' +
          '<rect x="11.2" y="22" width="1.6" height="10" rx="0.4" fill="#fff"/>';
      }
      if (mode === "metro") {
        return '<rect x="2" y="3" width="20" height="30" rx="9" fill="' + color + '"/>' +
          '<rect x="5" y="6.5" width="14" height="3.2" rx="1.4" fill="#fff"/>' +
          '<rect x="5" y="13" width="14" height="2.6" rx="1" fill="#fff"/>' +
          '<rect x="5" y="18.5" width="14" height="2.6" rx="1" fill="#fff"/>' +
          '<rect x="5" y="24" width="14" height="2.6" rx="1" fill="#fff"/>';
      }
      return '<rect x="5" y="2" width="14" height="32" rx="2.5" fill="' + color + '"/>' +
        '<rect x="7" y="4" width="10" height="4" rx="0.8" fill="#fff"/>' +
        '<rect x="6.2" y="11" width="2.2" height="16" rx="0.5" fill="#fff"/>' +
        '<rect x="15.6" y="11" width="2.2" height="16" rx="0.5" fill="#fff"/>';
    }

    function vehicleHtml(mode, color, line, heading) {
      const kind = mode === "tram" || mode === "metro" ? mode : "bus";
      const rotation = heading == null ? 0 : heading;
      return '<div class="veh"><svg width="24" height="36" viewBox="0 0 24 36" data-mode="' + kind +
        '" aria-hidden="true" style="transform:rotate(' + rotation + 'deg)">' +
        vehicleBody(kind, color) +
        '</svg><span>' + line + '</span></div>';
    }

    function vehicleIcon(mode, color, line, heading) {
      return L.divIcon({
        className: '',
        html: vehicleHtml(mode, color, line, heading),
        iconSize: [44, 54],
        iconAnchor: [22, 18]
      });
    }

    function syncVehicles(vehicles) {
      const seen = new Set();
      const now = performance.now();
      (vehicles || []).forEach((vehicle) => {
        seen.add(vehicle.id);
        const nextLat = Number(vehicle.latitude);
        const nextLng = Number(vehicle.longitude);
        const color = escapeHtml(vehicle.color);
        const line = escapeHtml(vehicle.line);
        const mode = vehicle.mode === "tram" || vehicle.mode === "metro" ? vehicle.mode : "bus";
        const current = vehicleMotions.get(vehicle.id);
        if (!current) {
          const heading = typeof vehicle.bearing === "number" ? vehicle.bearing : null;
          const marker = L.marker([nextLat, nextLng], { icon: vehicleIcon(mode, color, line, heading) });
          marker.on('click', () => parent.postMessage({ source: 'tcl-map', type: 'vehicle', id: vehicle.id }, '*'));
          marker.addTo(vehiclesLayer);
          vehicleMotions.set(vehicle.id, {
            marker, fromLat: nextLat, fromLng: nextLng, toLat: nextLat, toLng: nextLng,
            start: now, duration: 1, signature: mode + '|' + color + '|' + line + '|' + heading
          });
          return;
        }
        const place = current.marker.getLatLng();
        const dLat = nextLat - place.lat;
        const dLng = nextLng - place.lng;
        const moved = Math.abs(dLat) > 0.00001 || Math.abs(dLng) > 0.00001;
        const jump = Math.abs(dLat) > 0.02 || Math.abs(dLng) > 0.02;
        const heading = travelHeading(place.lat, place.lng, nextLat, nextLng, vehicle.bearing);
        const signature = mode + '|' + color + '|' + line + '|' + (heading == null ? '' : Math.round(heading));
        if (current.signature !== signature) {
          current.signature = signature;
          current.marker.setIcon(vehicleIcon(mode, color, line, heading));
        }
        current.fromLat = place.lat;
        current.fromLng = place.lng;
        current.toLat = nextLat;
        current.toLng = nextLng;
        current.start = now;
        current.duration = moved && !jump ? SLIDE_MS : 1;
      });
      vehicleMotions.forEach((motion, id) => {
        if (seen.has(id)) return;
        vehiclesLayer.removeLayer(motion.marker);
        vehicleMotions.delete(id);
      });
    }

    function slideVehicles(now) {
      vehicleMotions.forEach((motion) => {
        if (motion.duration <= 0) return;
        const progress = Math.min(1, (now - motion.start) / motion.duration);
        motion.marker.setLatLng([
          motion.fromLat + (motion.toLat - motion.fromLat) * progress,
          motion.fromLng + (motion.toLng - motion.fromLng) * progress
        ]);
        if (progress >= 1) motion.duration = 0;
      });
      requestAnimationFrame(slideVehicles);
    }
    requestAnimationFrame(slideVehicles);

    function publishRegion() {
      const bounds = map.getBounds();
      const center = map.getCenter();
      parent.postMessage({
        source: 'tcl-map',
        type: 'region',
        latitude: center.lat,
        longitude: center.lng,
        latitudeDelta: bounds.getNorth() - bounds.getSouth(),
        longitudeDelta: bounds.getEast() - bounds.getWest()
      }, '*');
    }

    window.addEventListener('message', (event) => {
      const data = event.data || {};
      if (data.type === 'tcl-focus') {
        map.setView([data.latitude, data.longitude], 15);
        return;
      }
      if (data.type !== 'tcl-data') return;
      stopsLayer.clearLayers();
      userLayer.clearLayers();
      (data.stops || []).forEach((stop) => {
        const marker = L.circleMarker([stop.latitude, stop.longitude], {
          radius: 6, color: '#D0121A', weight: 2, fillColor: '#fff', fillOpacity: 1
        });
        marker.bindTooltip(stop.name, { direction: 'top' });
        marker.on('click', () => parent.postMessage({ source: 'tcl-map', type: 'stop', id: stop.id }, '*'));
        marker.addTo(stopsLayer);
      });
      syncVehicles(data.vehicles);
      if (data.userLocation) {
        L.circleMarker([data.userLocation.latitude, data.userLocation.longitude], {
          radius: 8, color: '#1A1714', weight: 2, fillColor: '#4C8DFF', fillOpacity: 1
        }).addTo(userLayer);
      }
    });

    map.on('moveend', publishRegion);
    map.whenReady(publishRegion);
  </script>
</body>
</html>`;

export const NetworkMap = forwardRef<NetworkMapHandle, NetworkMapProps>(function NetworkMap(
  { stops, vehicles, userLocation, onSelectStop, onSelectVehicle, onRegionChange },
  ref,
) {
  const frameRef = useRef<HTMLIFrameElement | null>(null);
  const onSelectStopRef = useRef(onSelectStop);
  const onSelectVehicleRef = useRef(onSelectVehicle);
  const onRegionChangeRef = useRef(onRegionChange);
  onSelectStopRef.current = onSelectStop;
  onSelectVehicleRef.current = onSelectVehicle;
  onRegionChangeRef.current = onRegionChange;

  useImperativeHandle(ref, () => ({
    focusOn(point: LatLng) {
      frameRef.current?.contentWindow?.postMessage({ type: "tcl-focus", ...point }, "*");
    },
  }));

  useEffect(() => {
    const onMessage = (event: MessageEvent) => {
      if (event.origin !== window.location.origin) {
        return;
      }
      const data = event.data as { source?: string; type?: string; id?: number | string } & Partial<MapRegion>;
      if (data?.source !== "tcl-map") {
        return;
      }
      if (data.type === "region") {
        onRegionChangeRef.current({
          latitude: Number(data.latitude),
          longitude: Number(data.longitude),
          latitudeDelta: Number(data.latitudeDelta),
          longitudeDelta: Number(data.longitudeDelta),
        });
      } else if (data.type === "stop" && typeof data.id === "number") {
        onSelectStopRef.current(data.id);
      } else if (data.type === "vehicle" && typeof data.id === "string") {
        onSelectVehicleRef.current(data.id);
      }
    };
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, []);

  useEffect(() => {
    frameRef.current?.contentWindow?.postMessage(
      {
        type: "tcl-data",
        stops,
        vehicles,
        userLocation,
      },
      "*",
    );
  }, [stops, vehicles, userLocation]);

  return (
    <View style={styles.fill}>
      {createElement("iframe", {
        ref: frameRef,
        title: "Carte TCL",
        srcDoc: MAP_DOCUMENT,
        style: { border: 0, width: "100%", height: "100%", background: "#e7e0d6" },
      })}
    </View>
  );
});

const styles = StyleSheet.create({
  fill: {
    flex: 1,
  },
});
