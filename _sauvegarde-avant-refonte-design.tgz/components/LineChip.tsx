import { StyleSheet, Text, View } from "react-native";

import { lineColor, theme } from "@/src/theme";

type LineChipProps = {
  line: string;
  size?: "md" | "lg";
};

export function LineChip({ line, size = "md" }: LineChipProps) {
  const large = size === "lg";
  return (
    <View style={[styles.chip, large && styles.large, { backgroundColor: lineColor(line) }]}>
      <Text style={[styles.label, large && styles.largeLabel]}>{line}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  chip: {
    borderRadius: 5,
    paddingHorizontal: 7,
    minWidth: 30,
    height: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  large: {
    minWidth: 40,
    height: 28,
    paddingHorizontal: 10,
    borderRadius: 6,
  },
  label: {
    color: theme.white,
    fontSize: 12,
    fontWeight: "800",
    letterSpacing: 0.2,
  },
  largeLabel: {
    fontSize: 15,
  },
});
