import type { VehicleMode } from "@/src/theme";
import type { LatLng, MapRegion } from "@/src/types";

export type MapStop = {
  id: number;
  name: string;
  latitude: number;
  longitude: number;
  lines: string[];
};

export type MapVehicle = {
  id: string;
  line: string;
  latitude: number;
  longitude: number;
  bearing: number | null;
  delayLabel: string | null;
  destination: string | null;
  color: string;
  mode: VehicleMode;
};

export type NetworkMapProps = {
  stops: MapStop[];
  vehicles: MapVehicle[];
  userLocation: LatLng | null;
  onSelectStop: (id: number) => void;
  onSelectVehicle: (id: string) => void;
  onRegionChange: (region: MapRegion) => void;
};

export type NetworkMapHandle = {
  focusOn: (point: LatLng) => void;
};
