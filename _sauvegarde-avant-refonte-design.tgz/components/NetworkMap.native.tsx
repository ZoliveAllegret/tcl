import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from "react";
import { StyleSheet, Text, View } from "react-native";
import MapView, { Marker, type Region } from "react-native-maps";

import type { NetworkMapHandle, NetworkMapProps } from "@/components/mapTypes";
import { theme, type VehicleMode } from "@/src/theme";
import type { LatLng } from "@/src/types";

const INITIAL_REGION: Region = {
  latitude: 45.7578,
  longitude: 4.832,
  latitudeDelta: 0.06,
  longitudeDelta: 0.06,
};

export const NetworkMap = forwardRef<NetworkMapHandle, NetworkMapProps>(function NetworkMap(
  { stops, vehicles, userLocation, onSelectStop, onSelectVehicle, onRegionChange },
  ref,
) {
  const mapRef = useRef<MapView>(null);
  const [trackMarkers, setTrackMarkers] = useState(true);

  const markerKey = vehicles
    .map((vehicle) => `${vehicle.id}:${vehicle.latitude}:${vehicle.longitude}:${vehicle.bearing ?? ""}:${vehicle.mode}`)
    .join("|");

  useEffect(() => {
    setTrackMarkers(true);
    const timer = setTimeout(() => setTrackMarkers(false), 700);
    return () => clearTimeout(timer);
  }, [markerKey]);

  useImperativeHandle(ref, () => ({
    focusOn(point: LatLng) {
      mapRef.current?.animateToRegion(
        {
          ...point,
          latitudeDelta: 0.02,
          longitudeDelta: 0.02,
        },
        400,
      );
    },
  }));

  useEffect(() => {
    onRegionChange(INITIAL_REGION);
  }, [onRegionChange]);

  return (
    <MapView
      ref={mapRef}
      style={styles.map}
      initialRegion={INITIAL_REGION}
      showsUserLocation={Boolean(userLocation)}
      onRegionChangeComplete={onRegionChange}
    >
      {stops.map((stop) => (
        <Marker
          key={`stop-${stop.id}`}
          coordinate={{ latitude: stop.latitude, longitude: stop.longitude }}
          pinColor={theme.red}
          title={stop.name}
          description={stop.lines.join(" · ")}
          onPress={() => onSelectStop(stop.id)}
        />
      ))}
      {vehicles.map((vehicle) => (
        <Marker
          key={`vehicle-${vehicle.id}`}
          coordinate={{ latitude: vehicle.latitude, longitude: vehicle.longitude }}
          anchor={{ x: 0.5, y: 0.5 }}
          tracksViewChanges={trackMarkers}
          onPress={() => onSelectVehicle(vehicle.id)}
        >
          <View style={styles.marker}>
            <View style={{ transform: [{ rotate: `${vehicle.bearing ?? 0}deg` }] }}>
              <VehicleGlyph mode={vehicle.mode} color={vehicle.color} />
            </View>
            <Text style={styles.vehicleLabel}>{vehicle.line}</Text>
          </View>
        </Marker>
      ))}
    </MapView>
  );
});

function VehicleGlyph({ mode, color }: { mode: VehicleMode; color: string }) {
  if (mode === "tram") {
    return (
      <View style={styles.tram}>
        <View style={[styles.tramCar, { backgroundColor: color }]}>
          <View style={styles.tramNose} />
          <View style={styles.tramStripe} />
        </View>
        <View style={[styles.tramCar, { backgroundColor: color }]}>
          <View style={styles.tramStripe} />
        </View>
      </View>
    );
  }
  if (mode === "metro") {
    return (
      <View style={[styles.metro, { backgroundColor: color }]}>
        <View style={styles.metroNose} />
        <View style={styles.metroBand} />
        <View style={styles.metroBand} />
        <View style={styles.metroBand} />
      </View>
    );
  }
  return (
    <View style={[styles.bus, { backgroundColor: color }]}>
      <View style={styles.windshield} />
      <View style={styles.sideWindows}>
        <View style={styles.window} />
        <View style={styles.window} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  map: {
    flex: 1,
  },
  marker: {
    alignItems: "center",
    gap: 2,
  },
  bus: {
    width: 14,
    height: 28,
    borderRadius: 3,
    alignItems: "center",
    paddingTop: 3,
    gap: 2,
  },
  windshield: {
    width: 8,
    height: 4,
    borderRadius: 1,
    backgroundColor: theme.white,
  },
  sideWindows: {
    flexDirection: "row",
    gap: 3,
  },
  window: {
    width: 2,
    height: 12,
    borderRadius: 1,
    backgroundColor: theme.white,
  },
  tram: {
    width: 8,
    height: 34,
    alignItems: "center",
    gap: 2,
  },
  tramCar: {
    width: 8,
    height: 16,
    borderRadius: 2,
    alignItems: "center",
    paddingTop: 2,
    gap: 2,
  },
  tramNose: {
    width: 5,
    height: 2,
    borderRadius: 1,
    backgroundColor: theme.white,
  },
  tramStripe: {
    width: 2,
    height: 8,
    borderRadius: 1,
    backgroundColor: theme.white,
  },
  metro: {
    width: 20,
    height: 28,
    borderRadius: 12,
    alignItems: "center",
    paddingTop: 3,
    gap: 2,
  },
  metroNose: {
    width: 14,
    height: 3,
    borderRadius: 2,
    backgroundColor: theme.white,
  },
  metroBand: {
    width: 14,
    height: 3,
    borderRadius: 1,
    backgroundColor: theme.white,
  },
  vehicleLabel: {
    color: theme.ink,
    fontSize: 11,
    fontWeight: "800",
    backgroundColor: theme.card,
    overflow: "hidden",
    borderRadius: 999,
    paddingHorizontal: 5,
    paddingVertical: 1,
  },
});
