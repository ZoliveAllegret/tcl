import { router, useNavigationContainerRef, usePathname } from "expo-router";
import { SymbolView, type SymbolViewProps } from "expo-symbols";
import { Platform, Pressable, StyleSheet, Text, View, type ViewStyle } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { requestNewSearch } from "@/src/search/session";
import { theme } from "@/src/theme";

type TabName = "index" | "lines" | "map" | "favorites";

type Destination = {
  label: string;
  screen: TabName;
  href: "/" | "/lines" | "/map" | "/favorites";
  fresh?: "stops" | "lines";
  ios: string;
  web: string;
};

const DESTINATIONS: Destination[] = [
  { label: "Recherche", screen: "index", href: "/", fresh: "stops", ios: "magnifyingglass", web: "search" },
  { label: "Lignes", screen: "lines", href: "/lines", fresh: "lines", ios: "list.bullet", web: "list" },
  { label: "Carte", screen: "map", href: "/map", ios: "map", web: "map" },
  { label: "Favoris", screen: "favorites", href: "/favorites", ios: "star", web: "star" },
];

const glass: ViewStyle =
  Platform.OS === "web"
    ? ({ backgroundColor: "rgba(255, 255, 255, 0.62)", backdropFilter: "blur(18px)" } as ViewStyle)
    : { backgroundColor: "rgba(255, 255, 255, 0.78)" };

export function useNavBarInset(): number {
  const insets = useSafeAreaInsets();
  return 78 + Math.max(insets.bottom, 8);
}

export function NavBar() {
  const insets = useSafeAreaInsets();
  const path = usePathname();
  const navigation = useNavigationContainerRef();

  function openDestination(destination: Destination) {
    if (destination.fresh) {
      requestNewSearch(destination.fresh);
    }
    if (router.canDismiss()) {
      router.dismissAll();
    }
    const tabsKey = navigation
      .getRootState()
      ?.routes.find((route) => route.name === "(tabs)")
      ?.state?.key;
    if (tabsKey) {
      navigation.dispatch({
        type: "JUMP_TO",
        target: tabsKey,
        payload: { name: destination.screen },
      });
      return;
    }
    router.navigate(destination.href);
  }

  return (
    <View style={[styles.bar, glass, { bottom: Math.max(insets.bottom, 8) }]}>
      {DESTINATIONS.map((destination) => {
        const active = isActive(path, destination.screen);
        const color = active ? theme.red : theme.muted;
        return (
          <Pressable
            key={destination.screen}
            onPress={() => openDestination(destination)}
            style={styles.item}
            accessibilityRole="button"
            accessibilityLabel={destination.label}
            accessibilityState={{ selected: active }}
          >
            <SymbolView
              name={
                {
                  ios: destination.ios,
                  android: destination.web,
                  web: destination.web,
                } as SymbolViewProps["name"]
              }
              tintColor={color}
              size={24}
            />
            <Text style={[styles.label, { color }]}>{destination.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

function isActive(path: string, screen: TabName): boolean {
  if (screen === "index") {
    return path === "/";
  }
  if (screen === "lines") {
    return path === "/lines" || path.startsWith("/line/");
  }
  return path === `/${screen}`;
}

const styles = StyleSheet.create({
  bar: {
    position: "absolute",
    left: 12,
    right: 12,
    bottom: 8,
    flexDirection: "row",
    borderRadius: 22,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "rgba(255, 255, 255, 0.8)",
    paddingTop: 8,
    paddingBottom: 8,
    zIndex: 20,
  },
  item: {
    flex: 1,
    alignItems: "center",
    gap: 2,
    paddingVertical: 4,
  },
  label: {
    fontSize: 11,
    fontWeight: "700",
  },
});
