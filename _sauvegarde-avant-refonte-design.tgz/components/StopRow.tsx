import { Pressable, StyleSheet, Text, View } from "react-native";

import { LineChip } from "@/components/LineChip";
import { usePlaceName } from "@/src/stops/placeName";
import { cardShadow, lineColor, theme } from "@/src/theme";
import type { Stop } from "@/src/types";

type StopRowProps = {
  stop: Stop;
  detail?: string;
  lookupPlace?: boolean;
  onPress: (stop: Stop) => void;
};

export function StopRow({ stop, detail, lookupPlace = true, onPress }: StopRowProps) {
  const placeName = usePlaceName(lookupPlace ? stop : undefined);
  const lines = stop.lines.slice(0, 4);
  const extra = stop.lines.length - lines.length;
  const meta = [placeName || stop.commune, detail, stop.wheelchair ? "PMR" : null].filter(Boolean).join("  ·  ");

  return (
    <Pressable
      onPress={() => onPress(stop)}
      style={({ pressed }) => [styles.row, pressed && styles.pressed]}
      accessibilityRole="button"
      accessibilityLabel={`${stop.name}, ${placeName || stop.commune}`}
    >
      <View style={[styles.rail, { backgroundColor: lineColor(stop.lines[0] ?? "") }]} />
      <View style={styles.body}>
        <View style={styles.copy}>
          <Text style={styles.name} numberOfLines={1}>
            {stop.name}
          </Text>
          <Text style={styles.meta} numberOfLines={1}>
            {meta}
          </Text>
        </View>
        <View style={styles.lines}>
          {lines.map((line) => (
            <LineChip key={line} line={line} />
          ))}
          {extra > 0 ? <Text style={styles.extra}>+{extra}</Text> : null}
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: "row",
    backgroundColor: theme.card,
    borderRadius: 16,
    marginBottom: 10,
    overflow: "hidden",
    ...cardShadow,
  },
  pressed: {
    backgroundColor: "#F7F4EF",
  },
  rail: {
    width: 5,
  },
  body: {
    flex: 1,
    paddingHorizontal: 14,
    paddingVertical: 13,
    gap: 10,
  },
  copy: {
    gap: 3,
  },
  name: {
    color: theme.ink,
    fontSize: 17,
    fontWeight: "700",
    letterSpacing: -0.2,
  },
  meta: {
    color: theme.muted,
    fontSize: 13,
  },
  lines: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 6,
    alignItems: "center",
  },
  extra: {
    color: theme.muted,
    fontSize: 12,
    fontWeight: "700",
  },
});
