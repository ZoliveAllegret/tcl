import type { ReactNode } from "react";
import { StyleSheet, Text, View } from "react-native";

import { theme } from "@/src/theme";

type ScreenHeaderProps = {
  title: string;
  children?: ReactNode;
};

export function ScreenHeader({ title, children }: ScreenHeaderProps) {
  return (
    <View style={styles.header}>
      <View style={styles.brandRow}>
        <View style={styles.mark} />
        <Text style={styles.brand}>TCL</Text>
      </View>
      <Text style={styles.title}>{title}</Text>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    backgroundColor: theme.card,
    paddingHorizontal: 20,
    paddingTop: 8,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: theme.line,
    gap: 12,
  },
  brandRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  mark: {
    width: 12,
    height: 12,
    borderRadius: 2,
    backgroundColor: theme.red,
  },
  brand: {
    color: theme.red,
    fontSize: 13,
    fontWeight: "800",
    letterSpacing: 1.6,
  },
  title: {
    color: theme.ink,
    fontSize: 32,
    fontWeight: "800",
    letterSpacing: -0.8,
  },
});
